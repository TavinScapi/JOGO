
def escolher_personagem(request):
    personagens = [
        {'nome': 'Guerreiro', 'descricao': 'Forte e resiliente, ideal para combate corpo a corpo.'},
        {'nome': 'Arqueiro', 'descricao': 'Ágil e preciso, ótimo em ataques à distância.'},
        {'nome': 'Mago', 'descricao': 'Mestre das magias, possui grande poder de ataque mágico.'}
    ]
    return render(request, 'JOGO/escolher_personagem.html', {'personagens': personagens})

from django.shortcuts import render

def menu(request):
    return render(request, 'JOGO/index.html')
def carregar_jogo(request):
    return render(request, 'JOGO/index.html')
def configuracoes(request):
    return render(request, 'JOGO/index.html')
def sair(request):
    return render(request, 'JOGO/index.html')

from django.shortcuts import render, redirect




def JOGO(request, parte='inicio'):
    historia_parte = historia.get(parte)
    if not historia_parte:
        return redirect('JOGO', parte='inicio')

    return render(request, 'JOGO/jogo.html', {'historia': historia_parte})

historia = {
    'inicio': {
        'texto': 'Você está em uma floresta escura. A lua ilumina fracamente o caminho, onde você vê duas trilhas: uma leva a uma caverna sombria com sons de ecos perturbadores, enquanto a outra segue para um antigo vilarejo, onde há rumores de que ninguém retorna.',
        'imagem': 'Leonardo_Phoenix_A_dense_dark_forest_illuminated_only_by_the_f_1 (1).jpg',  # Imagem para a floresta
        'escolhas': [
            {'texto': 'Ir para a caverna', 'proximo': 'caverna_entrada'},
            {'texto': 'Seguir para o vilarejo', 'proximo': 'vilarejo'}
        ]
    },
    'caverna_entrada': {
        'texto': 'Dentro da caverna, o som de gotas ecoa, e há um cheiro estranho de podridão. Você vê uma passagem estreita à direita, mas parece que algo se move ali. À esquerda, um túnel largo parece promissor, mas há pegadas que indicam que algo pesado passou recentemente.',
        'imagem': 'Leonardo_Phoenix_Inside_a_dark_damp_cave_with_echoes_of_drippi_1.jpg',  # Imagem para a entrada da caverna
        'escolhas': [
            {'texto': 'Explorar a passagem estreita, apesar do perigo', 'proximo': 'passagem_estreita'},
            {'texto': 'Seguir pelo túnel largo, mesmo com o risco de encontrar uma criatura perigosa', 'proximo': 'tunel_largo'}
        ]
    },
    'passagem_estreita': {
        'texto': 'A passagem é extremamente apertada, e você luta para se mover. No final, encontra um baú antigo coberto de pó, mas sente que não está sozinho ali.',
        'imagem': 'Leonardo_Phoenix_A_dimly_lit_serpentine_cave_passage_constrict_2.jpg',  # Imagem para a passagem estreita
        'escolhas': [
            {'texto': 'Abrir o baú e arriscar a presença de algo desconhecido', 'proximo': 'bau'},
            {'texto': 'Sair silenciosamente e voltar para a entrada da caverna', 'proximo': 'caverna_entrada'}
        ]
    },
    'bau': {
        'texto': 'Ao abrir o baú, você encontra uma espada antiga, mas enferrujada. Pegá-la pode ser um risco devido à sua condição, mas deixá-la também parece um desperdício.',
        'imagem': 'Leonardo_Phoenix_A_weathered_ancient_chest_with_intricate_rust_1.jpg',  # Imagem do baú
        'escolhas': [
            {'texto': 'Pegar a espada e enfrentar o perigo, mesmo com o risco dela quebrar', 'proximo': 'tunel_largo'},
            {'texto': 'Deixar a espada e voltar, aceitando a desvantagem', 'proximo': 'caverna_entrada'}
        ]
    },
    'tunel_largo': {
        'texto': 'Você caminha pelo túnel, mas encontra um dragão adormecido bloqueando a saída. Ele guarda um brilho hipnotizante, possivelmente um tesouro.',
        'imagem': 'Leonardo_Phoenix_A_massive_sleeping_dragon_guarding_a_glowing_3.jpg',  # Imagem do dragão adormecido
        'escolhas': [
            {'texto': 'Arriscar pegar o tesouro silenciosamente', 'proximo': 'dragao_tesouro'},
            {'texto': 'Atacar o dragão com a espada, ciente de que pode ser fatal', 'proximo': 'lutar_dragao'},
            {'texto': 'Desistir do tesouro e voltar antes que o dragão acorde', 'proximo': 'caverna_entrada'}
        ]
    },
    'dragao_tesouro': {
        'texto': 'Você tenta se aproximar, mas o dragão acorda, lançando chamas ao seu redor. Em uma tentativa desesperada, você tenta fugir, mas ele é rápido. Você é consumido pelas chamas. Fim do jogo.',
        'imagem': 'dragao_chamas.jpg',  # Imagem do dragão lançando chamas
        'escolhas': [
            {'texto': 'Recomeçar', 'proximo': 'inicio'}
        ]
    },
    'lutar_dragao': {
        'texto': 'Você luta bravamente com a espada enferrujada. Após uma batalha intensa, a lâmina quebra, mas você consegue ferir o dragão. Com sorte, ele foge, deixando o tesouro para trás. Você venceu, mas saiu gravemente ferido.',
        'imagem': 'batalha_dragao.jpg',  # Imagem da batalha com o dragão
        'escolhas': [
            {'texto': 'Recomeçar', 'proximo': 'inicio'}
        ]
    },
    'vilarejo': {
        'texto': 'Você chega ao vilarejo deserto. Há uma taberna abandonada, onde rumores dizem que espíritos habitam, e uma igreja sombria ao longe, onde já houve avistamentos de sombras.',
        'imagem': 'vilarejo.jpg',  # Imagem do vilarejo
        'escolhas': [
            {'texto': 'Explorar a taberna, ignorando os rumores de assombrações', 'proximo': 'taberna'},
            {'texto': 'Ir até a igreja e investigar a presença das sombras', 'proximo': 'igreja'}
        ]
    },
    'taberna': {
        'texto': 'Dentro da taberna, você encontra um diário detalhando avistamentos de uma criatura mortal que caça à noite. O lugar é frio, e parece que alguém está te observando.',
        'imagem': 'taberna.jpg',  # Imagem da taberna
        'escolhas': [
            {'texto': 'Ler mais sobre a criatura, arriscando perder tempo e atrair algo', 'proximo': 'criatura'},
            {'texto': 'Ignorar o diário e sair da taberna', 'proximo': 'vilarejo'}
        ]
    },
    'criatura': {
        'texto': 'Enquanto lê, um uivo ressoa. A criatura se aproxima. Você sente que está sem saída.',
        'imagem': 'criatura.jpg',  # Imagem da criatura
        'escolhas': [
            {'texto': 'Tentar se esconder na taberna, com risco de ser encontrado', 'proximo': 'esconderijo_taberna'},
            {'texto': 'Correr para a igreja, mesmo sabendo que a criatura pode te seguir', 'proximo': 'igreja'}
        ]
    },
    'esconderijo_taberna': {
        'texto': 'Você se esconde atrás do balcão. A criatura entra, farejando o ar, mas eventualmente vai embora. Ao amanhecer, você foge exausto, mas seguro, do vilarejo.',
        'imagem': 'esconderijo_taberna.jpg',  # Imagem do esconderijo na taberna
        'escolhas': [
            {'texto': 'Recomeçar', 'proximo': 'inicio'}
        ]
    },
    'igreja': {
        'texto': 'Na igreja sombria, você encontra um sacerdote cansado que revela que a criatura é uma maldição lançada sobre o vilarejo. Ele oferece um ritual perigoso para quebrar a maldição.',
        'imagem': 'igreja.jpg',  # Imagem da igreja sombria
        'escolhas': [
            {'texto': 'Aceitar a ajuda do sacerdote, com risco de falha no ritual', 'proximo': 'quebrar_maldicao'},
            {'texto': 'Recusar e continuar explorando sozinho, mesmo com o perigo iminente', 'proximo': 'explorar_vilarejo'}
        ]
    },
    'quebrar_maldicao': {
        'texto': 'O sacerdote inicia o ritual, mas avisa que qualquer interrupção pode ser fatal. A criatura aparece e tenta atacar, mas o ritual é concluído a tempo. O vilarejo está livre, mas o sacerdote foi ferido mortalmente. Você é saudado como um herói, mas carrega o peso da perda.',
        'imagem': 'quebrar_maldicao.jpg',  # Imagem do ritual quebrando a maldição
        'escolhas': [
            {'texto': 'Recomeçar', 'proximo': 'inicio'}
        ]
    },
    'explorar_vilarejo': {
        'texto': 'Você explora o vilarejo, mas a criatura te encontra e a perseguição começa. Você corre, mas tropeça e é capturado. Fim do jogo.',
        'imagem': 'captura.jpg',  # Imagem da captura pela criatura
        'escolhas': [
            {'texto': 'Recomeçar', 'proximo': 'inicio'}
        ]
    }
}


from django.shortcuts import render, redirect


def processar_dados(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        email = request.POST.get('email')
        data_nascimento = request.POST.get('data_nascimento')
        cpf = request.POST.get('cpf')
        cartao = request.POST.get('cartao')
        cvv = request.POST.get('cvv')

        # Lógica de processamento dos dados
        # (por exemplo, salvar em um banco de dados ou enviar um e-mail)

        return redirect('menu')  # Redireciona para uma página de sucesso
    return render(request, 'JOGO/index.html')  # Renderiza o formulário se o método for GET
